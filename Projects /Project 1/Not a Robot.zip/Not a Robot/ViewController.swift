//
//  ViewController.swift
//  Not a Robot
//
//  Created by Albert Jin on 10/8/19.
//  Copyright © 2019 AJ Studio. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    var correctOrientation:Double? = 0.1
    var fontSize:Float? = 12
    var aOrientation:Double? = 0.1
    var aSize:Float? = 18
    
    @IBOutlet weak var orientationLabel: UILabel!
    @IBOutlet weak var sizeLabel: UILabel!
    @IBOutlet weak var ORotation: UILabel!
    @IBOutlet weak var OFontSize: UILabel!
    @IBOutlet weak var OLabel: UILabel! // the original label
    @IBOutlet weak var aLabel: UILabel! // the label user will change the orientation and size of the font to match the original label
    @IBOutlet weak var OrientationSlider: UISlider!
    @IBOutlet weak var SizeSlider: UISlider!

    
    @IBAction public func setUp(sender: AnyObject){
        let correctOrientation = Double.random(in: 0..<1)
        OLabel.transform = CGAffineTransform(rotationAngle: CGFloat(correctOrientation *  2.0 * .pi))
        let fontSize = Float.random(in: 6 ... 24)
        let fontSizeCGFloat = CGFloat(fontSize)
        OLabel.font = UIFont.systemFont(ofSize: fontSizeCGFloat)
        ORotation.text = String(Double(correctOrientation))
        OFontSize.text = String(Float(fontSize))
        upDate()
    }
    
    
    @IBAction func changeFontSize (_ sender: UISlider) {
        let aSize = sender.value //float
        let SizeCGFloat = CGFloat(aSize) //convert float to CGFloat
        aLabel.font=UIFont.systemFont(ofSize: SizeCGFloat) //create a UIFont object and assign to the font property
        upDate()
    }
    
    @IBAction func changeFontOrientation (_ sender: UISlider) {
        let aOrientation = Double(sender.value) //Double
        aLabel.transform = CGAffineTransform(rotationAngle: CGFloat(aOrientation * 2.0 * .pi))
        // partially learned from https://www.youtube.com/watch?v=I286E98s3Ig
        upDate()
    }
    
    @IBAction func HoriSlider(_ sender: UISlider) {
        sizeLabel.text = String(Float(aSize!))
    }
    @IBAction func VerticalSlider(_ sender: UISlider) {
        //        let angle:Int = Int(OrientationSlider.value * 180.0/.pi)
        orientationLabel.text = String(Double(aOrientation!))
    }
    
    func upDate() {
        let a = correctOrientation! - 0.02
        let b = correctOrientation! + 0.02
        let c = fontSize! - 0.3
        let d = fontSize! + 0.3
        if a < aOrientation! && aOrientation! < b && c < aSize! && aSize! < d {
            //create a UIAlertController object
            let alert=UIAlertController(title: "Warning", message: "You pass the test!", preferredStyle: UIAlertController.Style.alert)
            //create a UIAlertAction object for the button
            let cancelAction=UIAlertAction(title: "Cancel", style:UIAlertAction.Style.cancel, handler: nil)
            alert.addAction(cancelAction) //adds the alert action to the alert object
            let okAction = UIAlertAction(title: "OK", style: UIAlertAction.Style.default, handler: {action in
                exit(0)
            })
            alert.addAction(okAction)
            present(alert, animated: true, completion: nil)
        }
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        let r:Double? = .pi/2 // make vertical
        OrientationSlider.transform = CGAffineTransform(rotationAngle: CGFloat(r!)) // learned from https://www.youtube.com/watch?v=u6Vru1v7DCo
    }


}

