//
//  ViewController.swift
//  Not a Robot
//
//  Created by Albert Jin on 10/8/19.
//  Copyright © 2019 AJ Studio. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
//    var correctOrientation:Double? = 0
//    var fontSize:Float? = 12
//    var aOrientation:Double? = 0.1
//    var aSize:Float? = 18
    
    @IBOutlet weak var orientationLabel: UILabel!
    @IBOutlet weak var sizeLabel: UILabel!
    @IBOutlet weak var ORotation: UILabel!
    @IBOutlet weak var OFontSize: UILabel!
    @IBOutlet weak var OLabel: UILabel! // the original label
    @IBOutlet weak var aLabel: UILabel! // the label user will change the orientation and size of the font to match the original label
    @IBOutlet weak var OrientationSlider: UISlider!
    @IBOutlet weak var SizeSlider: UISlider!

    var wordbank:[String] = ["Tripping Farmers", "Self-driving RVS", "Weenie Roast", "Burgervision", "Party Hose", "Deluxe Workouts","Definitely Rickles","Pineapple Caper","Eye Ear"] // word list from http://trianglesinspace.com/trending3000/ by Colleen Macklin
    
    @IBAction public func setUp(sender: AnyObject){
        let correctOrientation = Double.random(in: 0..<1)
        OLabel.transform = CGAffineTransform(rotationAngle: CGFloat(correctOrientation *  2.0 * .pi))
        let fontSize = Float.random(in: 6 ... 24)
        let fontSizeCGFloat = CGFloat(fontSize)
        OLabel.font = UIFont.systemFont(ofSize: fontSizeCGFloat)
        let number = Int.random(in: 0...8)
        let wordPrint = wordbank[number]
        OLabel.text = String(wordPrint)
        aLabel.text = String(wordPrint)
        ORotation.text = String(Double(correctOrientation))
        OFontSize.text = String(Float(fontSize))
        upDate()
    }
    
    
    @IBAction func changeFontSize (_ sender: UISlider) {
        let aSize = sender.value //float
        sizeLabel.text = String(Float(aSize))
        let SizeCGFloat = CGFloat(aSize) //convert float to CGFloat
        aLabel.font=UIFont.systemFont(ofSize: SizeCGFloat) //create a UIFont object and assign to the font property
        upDate()
    }
    
    @IBAction func changeFontOrientation (_ sender: UISlider) {
        let aOrientation = Double(sender.value) //Double
        orientationLabel.text = String(Double(aOrientation))
        aLabel.transform = CGAffineTransform(rotationAngle: CGFloat(aOrientation * 2.0 * .pi))
        // partially learned from https://www.youtube.com/watch?v=I286E98s3Ig
        upDate()
    }
    
    
    func upDate() {
        let a : Double = Double(ORotation.text!)! - 0.02
        let b : Double = Double(ORotation.text!)! + 0.02
        let c : Float = Float(OFontSize.text!)! - 0.3
        let d : Float = Float(OFontSize.text!)! + 0.3
        if a < Double(orientationLabel.text!)! && Double(orientationLabel.text!)! < b && c < Float(sizeLabel.text!)! && Float(sizeLabel.text!)! < d {
            //create a UIAlertController object
            let alert=UIAlertController(title: "Great Job!", message: "You pass the test!", preferredStyle: UIAlertController.Style.alert)
            //create a UIAlertAction object for the button
            let cancelAction=UIAlertAction(title: "OK", style:UIAlertAction.Style.cancel, handler: nil)
            alert.addAction(cancelAction) //adds the alert action to the alert object
//            let okAction = UIAlertAction(title: "OK", style: UIAlertAction.Style.default, handler: {action in
//                self.setUp(sender: AnyObject as AnyObject)
//            })
//            alert.addAction(okAction)
            present(alert, animated: true, completion: nil)
        }
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        let r:Double? = .pi/2 // make vertical
        OrientationSlider.transform = CGAffineTransform(rotationAngle: CGFloat(r!)) // learned from https://www.youtube.com/watch?v=u6Vru1v7DCo
    }

}

