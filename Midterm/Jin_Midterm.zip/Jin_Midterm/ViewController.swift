//
//  ViewController.swift
//  Jin_Midterm
//
//  Created by Albert Jin on 10/15/19.
//  Copyright © 2019 AJ Studio. All rights reserved.
//

import UIKit

class ViewController: UIViewController, UITextFieldDelegate {

    @IBOutlet weak var miles: UITextField!
    @IBOutlet weak var transImage: UIImageView!
    @IBOutlet weak var transControl: UISegmentedControl!
    @IBOutlet weak var gasInTank: UILabel!
    @IBOutlet weak var GiT: UISlider!
    @IBOutlet weak var GastoPurchase: UILabel!
    @IBOutlet weak var TotalcommuteTime: UILabel!
    @IBOutlet weak var monthlySwitch: UISwitch!
    
    func updateImage(){
        if transControl.selectedSegmentIndex == 0 {
            transImage.image=UIImage(named: "car_icon")
            let alert=UIAlertController(title: "Hey yoooo~", message: "We recommend car pool or use other environmental friendly transportation!", preferredStyle: UIAlertController.Style.alert)
            //create a UIAlertAction object for the button
            let cancelAction=UIAlertAction(title: "I want drive", style:UIAlertAction.Style.cancel, handler: nil)
            alert.addAction(cancelAction) //adds the alert action to the alert object
            let okActiona = UIAlertAction(title: "Go bus", style: UIAlertAction.Style.default, handler: {action in
                self.transControl.selectedSegmentIndex = 1
                self.transImage.image=UIImage(named: "bus_icon")
            })
            
            alert.addAction(okActiona)
            let okActionb = UIAlertAction(title: "Go bike", style: UIAlertAction.Style.default, handler: {action in
                self.transControl.selectedSegmentIndex = 2
                self.transImage.image=UIImage(named: "bike_icon")
            })
            alert.addAction(okActionb)
            present(alert, animated: true, completion: nil)
        }
        else if transControl.selectedSegmentIndex == 1 {
            transImage.image=UIImage(named: "bus_icon")
        }
        else if transControl.selectedSegmentIndex == 2 {
            transImage.image=UIImage(named: "bike_icon")
        }
    }
    
    func updateGtP(){
        if transControl.selectedSegmentIndex == 0 {
            var amount : Float // miles amount
            let GIT : Float = GiT.value // gas in tank
            let mpg : Float = 24
            var GtP : Float
            
            if miles.text!.isEmpty {
                amount = 0.0
            } else {
                amount = Float(miles.text!)!
            }
            if miles.text!.isEmpty {
                amount = 0.0
            } else {
                amount = Float(miles.text!)!
            }
            GtP = amount/mpg - GIT
            if GtP > 0{
                GastoPurchase.text=String(round(GtP*100)/100)
            }else{
                GtP = 0
                GastoPurchase.text=String(round(GtP*100)/100)
            }
            
            if monthlySwitch.isOn{
                amount = 20.0 * amount
                GtP = amount/mpg - GIT
                if GtP > 0{
                    GastoPurchase.text=String(round(GtP*100)/100)
                }else{
                    GtP = 0
                    GastoPurchase.text=String(round(GtP*100)/100)
                }
            }
        }else{
            let GtP : Float = 0.0
            GastoPurchase.text=String(round(GtP*100)/100)
        }
    }
    
    func updateCT(){
        if transControl.selectedSegmentIndex == 0 { // car
            var amount : Float // miles amount
            let speed : Float = 20/60 // speed in miles per min
            var time : Float
            
            if miles.text!.isEmpty {
                amount = 0.0
            } else {
                amount = Float(miles.text!)!
            }
            if miles.text!.isEmpty {
                amount = 0.0
            } else {
                amount = Float(miles.text!)!
            }
            
            if monthlySwitch.isOn{
                time = 20.0 * amount/speed
                TotalcommuteTime.text = String(round(time*100)/100)
            }else{
                time = amount/speed
                TotalcommuteTime.text = String(round(time*100)/100)
            }
            
        }
        else if transControl.selectedSegmentIndex == 1 { // bus
            var amount : Float // miles amount
            let speed : Float = 12/60 // speed in miles per min
            var time : Float
            
            if miles.text!.isEmpty {
                amount = 0.0
            } else {
                amount = Float(miles.text!)!
            }
            if miles.text!.isEmpty {
                amount = 0.0
            } else {
                amount = Float(miles.text!)!
            }
            
            if monthlySwitch.isOn{
                time = 20.0 * (amount/speed + 10.0)
                TotalcommuteTime.text = String(round(time*100)/100)
            }else{
                time = amount/speed + 10.0
                TotalcommuteTime.text = String(round(time*100)/100)
            }
            
            
        }else if transControl.selectedSegmentIndex == 2 { // bike
            var amount : Float // miles amount
            let speed : Float = 10/60 // speed in miles per min
            var time : Float
            
            if miles.text!.isEmpty {
                amount = 0.0
            } else {
                amount = Float(miles.text!)!
            }
            if miles.text!.isEmpty {
                amount = 0.0
            } else {
                amount = Float(miles.text!)!
            }
            
            if monthlySwitch.isOn{
                time = 20.0 * amount/speed
                TotalcommuteTime.text = String(round(time*100)/100)
            }else{
                time = amount/speed
                TotalcommuteTime.text = String(round(time*100)/100)
            }
        }
    }
    
    @IBAction func updateTrans(_ sender: UISegmentedControl) {
        updateImage()
        updateCT()
        updateGtP()
    }
    
    @IBAction func monthlyBool(_ sender: UISwitch) {
        updateGtP()
        updateCT()
    }
    
    @IBAction func changegasInTank(_ sender: UISlider) {
        let gas=sender.value //float
        gasInTank.text=String(round(100*gas)/100) //convert float to String
    }
    
    
    func textFieldDidEndEditing(_ textField: UITextField) {
        updateGtP()
        updateCT()
    }
    
    @IBAction func Calculate(_ sender: UIButton) {
        updateGtP()
        updateCT()
    }
    
    @objc func dismissKeyboard() {
        view.endEditing(true)
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        miles.delegate=self
        NotificationCenter.default.addObserver(self, selector:
            #selector(keyboardWillShow), name: UIResponder.keyboardWillShowNotification, object: nil)
        NotificationCenter.default.addObserver(self, selector:
            #selector(keyboardWillHide), name: UIResponder.keyboardWillHideNotification, object: nil)
        
        let tap: UITapGestureRecognizer =
            UITapGestureRecognizer(target: self, action:
                #selector(self.dismissKeyboard))
        view.addGestureRecognizer(tap)
    }

    
    @objc func keyboardWillShow(notification: NSNotification) {
        if let keyboardSize = (notification.userInfo?[UIResponder.keyboardFrameEndUserInfoKey] as? NSValue)?.cgRectValue {
            if self.view.frame.origin.y == 0 {
                self.view.frame.origin.y = 0
            }
        }
    }
    
    @objc func keyboardWillHide(notification: NSNotification) {
        if ((notification.userInfo?[UIResponder.keyboardFrameEndUserInfoKey] as? NSValue)?.cgRectValue)
            != nil {
            if self.view.frame.origin.y != 0 {
                self.view.frame.origin.y = 0
            }
        }
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

}

