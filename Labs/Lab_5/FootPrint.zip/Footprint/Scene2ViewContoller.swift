//
//  Scene2ViewContoller.swift
//  Footprint
//
//  Created by Albert Jin on 10/21/19.
//  Copyright © 2019 AJ Studio. All rights reserved.
//

import UIKit

class Scene2ViewContoller: UIViewController, UITextFieldDelegate {

    @IBOutlet weak var userPlace: UITextField!
    @IBOutlet weak var userCountry: UITextField!
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "done"{
            let scene1ViewController = segue.destination as! ViewController
            //check to see that text was entered in the textfields
            if userPlace.text!.isEmpty == false{
                scene1ViewController.user.placebeen=userPlace.text
            }
            if userCountry.text!.isEmpty == false{
                scene1ViewController.user.countrybeen=userCountry.text
            }
        }
    }
    
    override func viewDidLoad() {
        userPlace.delegate=self
        userCountry.delegate=self
        super.viewDidLoad()
    }
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        textField.resignFirstResponder()
        return true
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    


    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
