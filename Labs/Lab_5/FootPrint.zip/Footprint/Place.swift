//
//  Place.swift
//  Footprint
//
//  Created by Albert Jin on 10/22/19.
//  Copyright © 2019 AJ Studio. All rights reserved.
//

import Foundation

class Place {
    var placebeen : String?
    var countrybeen : String?
}
