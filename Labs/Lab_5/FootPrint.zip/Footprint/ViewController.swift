//
//  ViewController.swift
//  Footprint
//
//  Created by Albert Jin on 10/20/19.
//  Copyright © 2019 AJ Studio. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var placeLabel: UILabel!
    @IBOutlet weak var countryLabel: UILabel!
    
    
    var user = Place()
    
    
    @IBAction func unwindSegue (_ segue:UIStoryboardSegue){
        placeLabel.text=user.placebeen
        countryLabel.text=user.countrybeen
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

