//
//  ViewController.swift
//  Mortgage Calculator
//
//  Created by Albert Jin on 10/3/19.
//  Copyright © 2019 AJ Studio. All rights reserved.
//

import UIKit

class ViewController: UIViewController, UITextFieldDelegate {

    @IBOutlet weak var housePrice: UITextField!
    @IBOutlet weak var downPayment: UITextField!
    @IBOutlet weak var years: UILabel!
    @IBOutlet weak var rate: UILabel!
    @IBOutlet weak var loanTerm: UIStepper!
    @IBOutlet weak var ppm: UILabel! // ppm stands for payment per month
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        textField.resignFirstResponder()
        return true
    }
    
    @IBAction func updateTerm(_ sender: UIStepper) {
        if loanTerm.value == 10 {
            years.text = "10"
            rate.text = "3.56" // data from https://www.consumerfinance.gov/
        } else if loanTerm.value == 15 {
            years.text = "15"
            rate.text = "3.6" // data from https://www.consumerfinance.gov/
        } else if loanTerm.value == 20 {
            years.text = "20"
            rate.text = "4.01" // data from https://www.consumerfinance.gov/
        } else if loanTerm.value == 25 {
            years.text = "25"
            rate.text = "4.05" // I made this up
        } else if loanTerm.value == 30 {
            years.text = "30"
            rate.text = "4.1" // data from https://www.consumerfinance.gov/
        }
        updatePPM()
    }
    
    func updatePPM() {
        var amount:Double // housePrice amount
        var paid:Double // down payment amount
        var pct:Double // Interest rate
        
        if housePrice.text!.isEmpty {
            amount = 0.0
        } else {
            amount = Double(housePrice.text!)!
        }
        if downPayment.text!.isEmpty {
            paid = 0.0
        }
        else {
            paid = Double(downPayment.text!)!
        }
        
        pct = Double(rate.text!)!/100 // convert into percentage
        
        let numberOfTerms : Double = loanTerm.value * 12
        let loan = amount - paid
        
        var PPM : Float = 0.0 //specify Float so it's not a Double
        let x : Float = Float(loan * pct * pow((1.0 + pct),numberOfTerms))
        let y : Float = Float(pow((1.0 + pct),numberOfTerms) - 1.0)
        
        if numberOfTerms >= 120 {
            PPM = x/y
        } else if numberOfTerms > 360 {
            let alert=UIAlertController(title: "Warning", message: "The number of terms must be less than 30", preferredStyle: UIAlertController.Style.alert)
            //create a UIAlertAction object for the button
            let cancelAction=UIAlertAction(title: "Cancel", style:UIAlertAction.Style.cancel, handler: nil)
            alert.addAction(cancelAction) //adds the alert action to the alert object
            let okAction = UIAlertAction(title: "OK", style: UIAlertAction.Style.default, handler: {action in
                self.loanTerm.value = 30
                self.years.text? = "30"
                self.updatePPM()
            })
            alert.addAction(okAction)
            present(alert, animated: true, completion: nil)
        }else {
            //create a UIAlertController object
            let alert=UIAlertController(title: "Warning", message: "The number of terms must be greater than 10", preferredStyle: UIAlertController.Style.alert)
            //create a UIAlertAction object for the button
            let cancelAction=UIAlertAction(title: "Cancel", style:UIAlertAction.Style.cancel, handler: nil)
            alert.addAction(cancelAction) //adds the alert action to the alert object
            let okAction = UIAlertAction(title: "OK", style: UIAlertAction.Style.default, handler: {action in
                self.loanTerm.value = 10
                self.years.text? = "10"
                self.updatePPM()
            })
            alert.addAction(okAction)
            present(alert, animated: true, completion: nil)
        } //end else
        
        //format results as currency
        let currencyFormatter = NumberFormatter()
        currencyFormatter.numberStyle=NumberFormatter.Style.currency //set the number style
        ppm.text=currencyFormatter.string(from: NSNumber(value: PPM)) //returns a formatted string

    }
    
    func textFieldDidEndEditing(_ textField: UITextField) {
        updatePPM()
    }
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        housePrice.delegate=self
        downPayment.delegate=self
        NotificationCenter.default.addObserver(self, selector:
            #selector(keyboardWillShow), name: UIResponder.keyboardWillShowNotification, object: nil)
        NotificationCenter.default.addObserver(self, selector:
            #selector(keyboardWillHide), name: UIResponder.keyboardWillHideNotification, object: nil)
        
        let tap: UITapGestureRecognizer =
            UITapGestureRecognizer(target: self, action:
                #selector(self.dismissKeyboard))
        view.addGestureRecognizer(tap)
        
    }
    
    @objc func dismissKeyboard() {
        view.endEditing(true)
    }
    
    @objc func keyboardWillShow(notification: NSNotification) {
        if let keyboardSize = (notification.userInfo?[UIResponder.keyboardFrameEndUserInfoKey] as? NSValue)?.cgRectValue {
            if self.view.frame.origin.y == 0 {
                self.view.frame.origin.y = 0
            }
        }
    }
    
    @objc func keyboardWillHide(notification: NSNotification) {
        if ((notification.userInfo?[UIResponder.keyboardFrameEndUserInfoKey] as? NSValue)?.cgRectValue)
            != nil {
            if self.view.frame.origin.y != 0 {
                self.view.frame.origin.y = 0
            }
        }
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

}

